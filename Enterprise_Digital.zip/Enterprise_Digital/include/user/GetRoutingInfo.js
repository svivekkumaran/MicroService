function csvJSON(csv){

  var lines=csv.split("\n");
  var result = [];
  var headers=lines[0].split(",");
	
  for(var i=1;i<lines.length;i++){

      var obj = {}; 
      var currentline=lines[i].split(",");

      for(var j=0;j<headers.length;j++){
          obj[headers[j]] = currentline[j];
      }
      result.push(obj);
  }
  return JSON.stringify(result); //JSON
}

//This should probably only be used if all JSON elements are strings
function xwwwfurlenc(srcjson){
    if(typeof srcjson !== "object")
      if(typeof console !== "undefined"){
        console.log("\"srcjson\" is not a JSON object");
        return null;
      }
    var u = encodeURIComponent;
    var urljson = "";
    var keys = Object.keys(srcjson);
    for(var i=0; i <keys.length; i++){
        urljson += u(keys[i]) + "=" + u(srcjson[keys[i]]);
        if(i < (keys.length-1))urljson+="&";
    }
    return urljson;
}

// Will only decode as strings
// Without embedding extra information, there is no clean way to
// know what type of variable it was.
function dexwwwfurlenc(urljson){
    var dstjson = {};
    var ret;
    var reg = /(?:^|&)(\w+)=(\w+)/g;
    while((ret = reg.exec(urljson)) !== null){
        dstjson[ret[1]] = ret[2];
    }
    return dstjson;
}

function getTreatmentMessageFromOPM(MsgName,OPMName)
{
	var vResponse='TREATMENT DEFAULT';
    try{
    	var vOPMData = _genesys.session.getListItemValue(OPMName,  'OPM'); 	
    	vResponse = vOPMData[MsgName];
       }	 
    catch (e) 
    {
    	vResponse='TREATMENT DEFAULT Message';
    }
    __Log(logMsg('PLAY Message getTreatmentMessageFromOPM Response: '+vResponse ));
    return vResponse;
	
}

function getMessageFromOPM(HOOP_OpenFlag,HOOP_Reason,OPMName)
{
	var vResponse='';
    try{
    	var vOPMData = _genesys.session.getListItemValue(OPMName,  'OPM');
    	if (HOOP_OpenFlag=='OPEN')
    		{vResponse = vOPMData.AckBodyOpenHours;}
    	else
    		{
    			vResponse = vOPMData.AckBodyClosedHours; 
    			if (HOOP_Reason=='Closed_Emergency') {vResponse = vOPMData.AckBodyEmergency;}
    			if (HOOP_Reason=='Holiday') {vResponse = vOPMData.AckBodyHolidays;}
    			if (HOOP_Reason=='Exception') {vResponse = vOPMData.AckBodySpecialDay;}
    		}
    	if (HOOP_Reason=='ChatBotMsg') {vResponse = vOPMData.AckBodyChatBot;}
       }	 
    catch (e) 
    {
    	vResponse='HOOP DEFAULT Message';
    }
    __Log(logMsg('PLAY Message getMessageFromOPM Response: '+vResponse ));
    return vResponse;
}

function setRoutingInfoFromJSON(info_type,info_detail,value){
	try{
	var retValue="";
	var interactionID = _data.system.context.InteractionID;
	var routing_info_JSON_string=getuData("ROUTING_INFO", interactionID);
	var routing_info_JSON=new Object();
	try{routing_info_JSON=JSON.parse(routing_info_JSON_string);
	} catch (e)
	{routing_info_JSON[info_type] = new Object();}
	
    if (typeof(routing_info_JSON[info_type])=='undefined')
      {routing_info_JSON[info_type] = new Object();}
    
    if (typeof(routing_info_JSON[info_type][info_detail])=='undefined')
    {routing_info_JSON[info_type][info_detail] = new Object();}
    
    routing_info_JSON[info_type][info_detail]=value;
        
    routing_info_JSON_string=JSON.stringify(routing_info_JSON);
    var data = new Object();
    var vTimeRpt=new Date();
	vTimeRpt=vTimeRpt.getTime();
	vTimeRpt=vTimeRpt.toString();
	data["Composer_internal_key"]=vTimeRpt;
    data["ROUTING_INFO"]=routing_info_JSON_string;
    _genesys.ixn.setuData(data, interactionID);
    return vTimeRpt;
	}	 
    catch (e) 
    { __Log(logMsg('setRoutingInfoFromJSON failed: '+uneval(e) ) ); 
    	return false; }
}

function setRoutingInfoSectionFromJSON(info_type,info_detail){
	try{
	var retValue="";
	var interactionID = _data.system.context.InteractionID;
	var routing_info_JSON_string=getuData("ROUTING_INFO", interactionID);
	var routing_info_JSON=new Object();
	try{routing_info_JSON=JSON.parse(routing_info_JSON_string);
	} catch (e)
	{routing_info_JSON[info_type] = new Object();}
	
    if (typeof(routing_info_JSON[info_type])=='undefined')
      {routing_info_JSON[info_type] = new Object();}
    routing_info_JSON[info_type]=info_detail;
    routing_info_JSON_string=JSON.stringify(routing_info_JSON);
    var data = new Object();
    var vTimeRpt=new Date();
	vTimeRpt=vTimeRpt.getTime();
	vTimeRpt=vTimeRpt.toString();
	data["Composer_internal_key"]=vTimeRpt;
    data["ROUTING_INFO"]=routing_info_JSON_string;
    _genesys.ixn.setuData(data, interactionID);
    return vTimeRpt;
	}	 
    catch (e) 
    { __Log(logMsg('setRoutingInfoFromJSON failed: '+uneval(e) ) ); 
    	return false; }
}

function getRoutingInfoSectionFromJSON(info_type){
	var retValue=new Object();
	try{
	var interactionID = _data.system.context.InteractionID;
	var routing_info_JSON_string=getuData("ROUTING_INFO", interactionID);
	var routing_info_JSON=JSON.parse(routing_info_JSON_string);
	if (typeof(routing_info_JSON[info_type])=='undefined')
    {routing_info_JSON[info_type] = new Object();}
	retValue = routing_info_JSON[info_type];
	return retValue;
	}
    catch (e) 
    { __Log(logMsg('getRoutingInfoSectionFromJSON failed: '+uneval(e) ) ); 
       	return retValue; 
    }
}

function getRoutingInfoFromJSON(info_type,info_detail){
	try{
	var retValue="";
	var JSON0="";
	var JSON1="";
	var JSON2="";
	var JSON3="";
	var interactionID = _data.system.context.InteractionID;
	var routing_info_JSON_string=getuData("ROUTING_INFO", interactionID);
	 
	var routing_info_JSON=JSON.parse(routing_info_JSON_string);
	if (typeof(routing_info_JSON[info_type])=='undefined')
    	{routing_info_JSON[info_type] = new Object();}
       switch(info_type)
       {
       
       case "Targets":
    	   var info_detail_arr=info_detail.split(".");
    	   JSON0=info_detail_arr[0];
    	   JSON1=info_detail_arr[1];
    	   if(JSON1=="Targets")
    		   {
    		   JSON2=parseInt(info_detail_arr[2]);
    		   __Log("JSON 2-->"+JSON2);
    		   JSON3=info_detail_arr[3];
    		   __Log("JSON 3-->"+JSON3);
    		   __Log("JSon_Obj-->"+JSON.stringify(routing_info_JSON));
    		   retValue=routing_info_JSON[info_type][JSON0][JSON1][JSON2][JSON3];
    		   }
    	   else
    		   {
    		   JSON2=info_detail_arr[2];
    		   retValue=routing_info_JSON[info_type][JSON0][JSON1][JSON2];
    		   }
    	   break;
    	   
       default:
    	   if (typeof(routing_info_JSON[info_type][info_detail])=='undefined')
    		   {retValue='false';}
    	   else
    		   {retValue = routing_info_JSON[info_type][info_detail];}
       }
       __Log("retValue -->"+retValue);
       return retValue;
	}
       catch (e) 
       { __Log(logMsg('getRoutingInfoFromJSON failed: '+uneval(e)+'    '+info_type+'    '+info_detail ) ); 
       	return 'false'; 
       	}
}
//TargetingResult.Targets.2.TargetType

//retValue=routing_info_JSON[Targets][TargetingResult][Targets][2][TargetType];

function analyzeHOOP(vJsonObject,vCallTypeString,vCurrentTime)
{

	var vResponse = new Object();
	var days = ['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'];
	var now = new Date(vCurrentTime);
	var dates = {
		    convert:function(d) {
		        // Converts the date in d to a date-object. The input can be:
		        //   a date object: returned without modification
		        //  an array      : Interpreted as [year,month,day]. NOTE: month is 0-11.
		        //   a number     : Interpreted as number of milliseconds
		        //                  since 1 Jan 1970 (a timestamp) 
		        //   a string     : Any format supported by the javascript engine, like
		        //                  "YYYY/MM/DD", "MM/DD/YYYY", "Jan 31 2009" etc.
		        //  an object     : Interpreted as an object with year, month and date
		        //                  attributes.  **NOTE** month is 0-11.
		        return (
		            d.constructor === Date ? d :
		            d.constructor === Array ? new Date(d[0],d[1],d[2]) :
		            d.constructor === Number ? new Date(d) :
		            d.constructor === String ? new Date(d) :
		            typeof d === "object" ? new Date(d.year,d.month,d.date) :
		            NaN
		        );
		    },
		    compare:function(a,b) {
		        // Compare two dates (could be of any type supported by the convert
		        // function above) and returns:
		        //  -1 : if a < b
		        //   0 : if a = b
		        //   1 : if a > b
		        // NaN : if a or b is an illegal date
		        // NOTE: The code inside isFinite does an assignment (=).
		        return (
		            isFinite(a=this.convert(a).valueOf()) &&
		            isFinite(b=this.convert(b).valueOf()) ?
		            (a>b)-(a<b) :
		            NaN
		        );
		    },
		    inRange:function(d,start,end) {
		        // Checks if date in d is between dates in start and end.
		        // Returns a boolean or NaN:
		        //    true  : if d is between start and end (inclusive)
		        //    false : if d is before start or after end
		        //    NaN   : if one or more of the dates is illegal.
		        // NOTE: The code inside isFinite does an assignment (=).
		       return (
		            isFinite(d=this.convert(d).valueOf()) &&
		            isFinite(start=this.convert(start).valueOf()) &&
		            isFinite(end=this.convert(end).valueOf()) ?
		            start <= d && d <= end :
		            NaN
		        );
		    }
		}
	vResponse.HOOP_CurrentTime =  now.toISOString();
	vResponse.HOOP_WeekDayName = days[now.getDay()];
	//"hoursOfOperation": "Mon-Fri:07:00AM-06:00PM",     2020-06-15T07:00:00-05:00  .
	vResponse.PreChat_Flag = vResponse.HOOP_WeekDayName+' '; 
	vResponse.HOOP_TimeZone = 'GMT';
	vResponse.callTypeMatch = false;
	if (vJsonObject.hasOwnProperty('callType') )
		{
			if (vJsonObject.callType==vCallTypeString)
				{
					vResponse.callTypeMatch = true;
					vResponse.HOOP_OpenFlag="false";
					vResponse.HOOP_LeftTime="0";
					vResponse.HOOP_BeginTime="";
					vResponse.HOOP_EndTime="";
					vResponse.HOOP_CalendarType='Regular';
					vResponse.HOOP_CalendarName='';
					vResponse.HOOP_CalendarDetail='';
					
					for (var i = 0; i < vJsonObject.calendarResults.length; i++)
					{
						var vStart = new Date(vJsonObject.calendarResults[i].start);
						var vEnd = new Date(vJsonObject.calendarResults[i].end);
						if (dates.compare(now,vStart)==1 && dates.compare(now,vEnd)==-1)
							{
								vResponse.HOOP_BeginTime = vStart;
								vResponse.HOOP_EndTime = vEnd;		
								vResponse.HOOP_LeftTime = Math.round((vEnd-now)/60000);
								vResponse.HOOP_CalendarType = vJsonObject.calendarResults[i].calendarReason;
								vResponse.HOOP_CalendarName = vJsonObject.calendarResults[i].calendarName;
								vResponse.HOOP_CalendarDetail = vJsonObject.calendarResults[i].calendarDetail;
								vResponse.HOOP_OpenFlag = vJsonObject.calendarResults[i].calendarStatus;
								vResponse.PreChat_Flag = vResponse.PreChat_Flag+vResponse.HOOP_OpenFlag+':'+vJsonObject.calendarResults[i].start.substr(11,5)+'-'+vJsonObject.calendarResults[i].end.substr(11,5)+'|US/Central';
								if (vResponse.HOOP_OpenFlag=='Open'){vResponse.HOOP_OpenFlag='true';}
								if (vResponse.HOOP_OpenFlag=='Closed'){vResponse.HOOP_OpenFlag='false';}
								
							}
						
					}
					
				}
		
		}
	return vResponse;

}