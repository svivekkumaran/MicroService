// jshint es3: false

// native imports
/* global __Log: false */
/* global _data: false */
/* global _genesys: false */
/* global getuData: false */

// scheduleUtils imports
/* global Schedule: false */

// moment imports
/* global moment: false */
/* global loadMoment: false */

// exports
/* global plog: true */
/* global getGRAVersion: true */
/* global getMediaType: true */
/* global getInteractionSubtype: true */
/* global getGroupContext: true */
/* global getServers: true */
/* global getInfrastructure: true */
/* global getLocalization: true */
/* global isOnline: true */
/* global nextOpeningTimeText: true */
/* global regularOpeningHoursText: true */
/* global timeInQueueText: true */

//##############################################################################
//# plog(?intro, ?name, o) -> o
//#
//# 'pretty' logs objects in an easily readable format
//#
function plog(intro, name, o) { //jshint ignore: line
	"use strict";

	var indent = arguments[3] || "",
	    prefix = "",
	    suffix = (arguments[4] ? "," : ""),
	    text = "",
	    keys,
	    last;

	if (arguments.length === 1) {
		// first and only arg is the object to log
		o = intro;
		intro = "";
		name = "";
	}
	else if (arguments.length === 2) {
		// first arg is the name, second is the object to log
		o = name;
		name = intro;
		intro = "";
	}

	if (name) {
		prefix = name + ": ";
	}

	if (indent === "") {
		if ( !_data.GRA.context.extra ||
		     !_data.GRA.context.extra.viewlog ||
		     (_data.GRA.context.extra.viewlog === "false")
		   ) {
			__Log(intro + prefix + JSON.stringify(o));
			return;
		}
	}

	if ( o && 
	     ( (Object.prototype.toString.apply(o) === "[object Object]") ||
	       (Object.prototype.toString.apply(o) === "[object object]") // sometimes needed in Eclipse/Rhino/Composer
	     )
	   ) {
		keys = Object.keys(o);
		if (keys.length === 0) {
			text += (text ? "<br/>" : "") + intro + indent + prefix + "{}" + suffix;
		}
		else {
			text += (text ? "<br/>" : "") + intro + indent + prefix + "{";
			last = keys.length - 1;
			keys.forEach(function (key, i) {
				text += (text ? "<br/>" : "") + plog(intro, key, o[key], indent + "&emsp;&emsp;", (i < last));
			});
			text += (text ? "<br/>" : "") + intro + indent + "}" + suffix;
		}
	}
	else if ( o && 
	          ( ( Object.prototype.toString.apply(o) === "[object Array]") ||
	            ( Object.prototype.toString.apply(o) === "[object array]") // sometimes needed for objects in Eclipse/Rhino/Composer, so also doing it for arrays
	          )
	        ) {
		if (o.length === 0) {
			text += (text ? "<br/>" : "") + intro + indent + prefix + "[]" + suffix;
		}
		else {
			text += (text ? "<br/>" : "") + intro + indent + prefix + "[";
			last = o.length - 1;
			o.forEach(function (x, i) {
				text += (text ? "<br/>" : "") + plog(intro, i, o[i], indent + "&emsp;&emsp;", (i < last));
			});
			text += (text ? "<br/>" : "") + intro + indent + "]" + suffix;
		}
	}
	else {
		text += (text ? "<br/>" : "") + intro + indent + prefix + JSON.stringify(o) + suffix;
	}

	if (indent === "") {
		__Log(text);
	}

	return text;
}

//##############################################################################
//#
//# getGRAVersion() -> versionString
//#
function getGRAVersion() { //jshint ignore: line
	"use strict";

	return "8.1.001.01-alpha.4";
}

//##############################################################################
//# getMediaType(?interactionID) -> string
//#
function getMediaType() { //jshint ignore: line
	"use strict";

	var category, media,
	    interactionID = arguments[0] || _data.system.context.InteractionID;

	var mediaMap = {
		"voice": {
			"TMediaVoice": "voice",
			"TMediaChat": "im"
		},
		"msgbased": {
			"TMediaEMail": "email",
			"TMediaNativeSMS": "sms"
		},
		"chat": {
			"TMediaChat": "chat"
		}
	};

	category = _genesys.ixn.interactions[interactionID].category;
	media = mediaMap[category][_genesys.ixn.interactions[interactionID][category].media] ||
	        _genesys.ixn.interactions[interactionID][category].media;

	return media;
}

//##############################################################################
//# getInteractionSubtype(?interactionID) -> string
//#
function getInteractionSubtype() { //jshint ignore: line
	"use strict";

	var category, type,
	    interactionID = arguments[0] || _data.system.context.InteractionID;

	var subtypeMap = { // mapping voice types to an interaction subtype
		"inbound": "InboundNew",
		"outbound": "OutboundNew",
		"internal": "", // cannot decide
		"consult": "", // cannot decide
		"callback": "OutboundNew"
	};

	category = _genesys.ixn.interactions[interactionID].category;
	type = _genesys.ixn.interactions[interactionID][category].type;

	return subtypeMap[type] || type;
}

//##############################################################################
//#
//# getGroupContext(?group) -> context
//#
//# gets the context for a group and memoizes it.  
//# The context is an object with structure:
//# {
//#     group: <parameter-group-name>
//#     template: <parameter-group-template-name>
//#     OPM: {
//#          <parameters>
//#     }
//#     extra: {
//#          <extra-arguments>
//#     }
//# }
//#
function getGroupContext(group) {
	"use strict";

	var workflowKey;
	var context, interactionID, mediaType, interactionSubtype, 
	    mailboxAddress, toAddress, fromAddress, acdq;
	var requestedGroup = group, hiddenGroup, OPM, regularOPM, hiddenOPM;
	var nextKey, mediaKeyMap = { "im": "IM", "sms": "SMS" };
	var prefix;

	function tryGroup(group, focus, process, media, address) {
		var hiddenGroup;

		if (group) {
			// this is a fully qualified group name
			if (getGroupContext._memoized[group]) {
				return group;
			}

			__Log("GRA> looking up transaction-list \'" + group + "\'");
			try {
				if (_genesys.session.listLookupValue(group, "OPM")) {
					return group;
				}
			}
			catch (e1) {}

			hiddenGroup = "_restricted_" + group;
			__Log("GRA> looking up transaction-list \'" + hiddenGroup + "\'");
			try {
				if (_genesys.session.listLookupValue(hiddenGroup, "OPM") ) {
					return group;
				}
			}
			catch (e2) {}

			return null;
		}
		else if (process === "collaboration") {
			// this is a group for the collaboration process
			return tryGroup("@collaboration.email > " + address) ||
			       tryGroup("@collaboration.email > " + address.split("@")[0]) ||
			       tryGroup("@collaboration.email") ||
			       tryGroup("@email");
		}
		else {
			return tryGroup( (focus || "") + "@" + (process || _data.GRA.process) + "." + (media || getMediaType()) ) ||
			       tryGroup( (focus || "") + "@" + (media || getMediaType()) ) ||
			       tryGroup( (focus || "") + "@" );
		}
	}

	if (!group) {
		// try a group based on an associated application
		group = _data.OPM_Transaction; // jshint ignore: line
		if (group && _data.system.context.OPM) {
			group = tryGroup(group);
		}

		// try a group based on interaction subtype specific rules
		if (!group) {
			// handle Collaboration subtypes slightly differently
			// if not successful, then fall through to normal rules
			interactionID = _data.system.context.InteractionID;
			mediaType = getMediaType();
			interactionSubtype = getInteractionSubtype();

			switch (mediaType) {
				case "voice":

					acdq = _genesys.ixn.interactions[interactionID].voice.acdq;
					if (acdq) {
						group = tryGroup(null, acdq, null, "voice");
					}

					break;
				case "im":

					acdq = _genesys.ixn.interactions[interactionID].voice.acdq;
					if (acdq) {
						group = tryGroup(null, acdq, null, "im");
					}

					break;
				case "email":

					switch (interactionSubtype) {
						case "InboundNew":
						case "InboundCustomerReply":
						case "InboundNDR":

							// first try the Mailbox address
							mailboxAddress = getuData("Mailbox", interactionID);
							if (mailboxAddress) {
								// only take the part before the @ in email-addresses
								group = tryGroup(null, mailboxAddress.split("@")[0], null, "email");
							}

							if (!group) {
								// try the To address, then fall through to the default group
								toAddress = getuData("To", interactionID);
								if (toAddress && (toAddress !== mailboxAddress)) {
									// only take the part before the @ in email-addresses
									group = tryGroup(null, toAddress.split("@")[0], null, "email");
								}
							}

							break;
						case "OutboundReply":
						case "OutboundAcknowledgement":
						case "OutboundAutoResponse":
						case "OutboundRedirect":

							// is this a reply to an inbound interaction that was previously processed by GRA?
							group = getuData("GRA_FirstEntryGroup", interactionID);
							if (group) {
								group = tryGroup(group);
							}

							if (group) {
								break;
							}
							/* falls through */
						case "OutboundNew":

							// this an outbound interaction that was not yet processed by GRA
							fromAddress = getuData("FromAddress", interactionID);
							if (fromAddress) {
								// only take the part before the @ in email-addresses
								group = tryGroup(null, fromAddress.split("@")[0], null, "email");
							}

							break;
						case "OutboundCollaborationInvite":

							// try the To address, then fall through to the default group
							toAddress = getuData("To", interactionID);
							if (toAddress) {
								group = tryGroup(null, null, "collaboration", "email", toAddress);
							}

							break;
						case "InboundCollaborationReply":

							// is this a reply to an outbound collaboration invite that was previously processed by GRA?
							group = getuData("GRA_FirstEntryGroup", interactionID);
							if (group) {
								group = tryGroup(group);
							}

							if (group) {
								break;
							}

							// this is a reply to an outbound collaboration invite that was not processed by GRA
							fromAddress = getuData("FromAddress", interactionID);
							if (fromAddress) {
								group = tryGroup(null, null, "collaboration", "email", fromAddress);
							}

							break;
						// the following are unexpected for GRA
						case "InternalCollaborationInvite": 
						case "InternalCollaborationReply":
						case "OutboundNotification":
						case "InboundDisposition":
						case "InboundReport":
							break;
						default:
							break;
					}

					break;
				case "sms":
				case "smssession":

					switch (interactionSubtype) {
						case "InboundNew":

							if (!group) {
								// try the To address, then fall through to the default group
								toAddress = getuData("_smsDestNumber", interactionID);
								if (toAddress) {
									group = tryGroup(null, toAddress, null, "sms");
								}
							}

							break;
						case "OutboundReply":
						case "OutboundAcknowledgement":
						case "OutboundAutoResponse":

							// is this a reply to an inbound interaction that was previously processed by GRA?
							group = getuData("GRA_FirstEntryGroup", interactionID);
							if (group) {
								group = tryGroup(group);
							}

							if (group) {
								break;
							}
							/* falls through */
						case "OutboundNew":

							// this an outbound interaction that was not yet processed by GRA
							fromAddress = getuData("_smsSrcNumber", interactionID);
							if (fromAddress) {
								group = tryGroup(null, fromAddress, null, "sms");
							}

							break;
					}

					break;
				case "facebook": 

					switch (interactionSubtype) {
						case "InboundNew":

							if (!group) {
								// try the To address, then fall through to the default group
								toAddress = getuData("_facebookSourceNickName", interactionID);
								if (toAddress) {
									group = tryGroup(null, toAddress, null, "facebook");
								}
							}

							break;
						case "OutboundReply":
						case "OutboundAcknowledgement":
						case "OutboundAutoResponse":

							// is this a reply to an inbound interaction that was previously processed by GRA?
							group = getuData("GRA_FirstEntryGroup", interactionID);
							if (group) {
								group = tryGroup(group);
							}

							if (group) {
								break;
							}
							/* falls through */
						case "OutboundNew":

							// this an outbound interaction that was not yet processed by GRA
							fromAddress = getuData("_facebookSourceNickName", interactionID);
							if (fromAddress) {
								group = tryGroup(null, fromAddress, null, "facebook");
							}

							break;
					}

					break;
				case "facebooksession":

					switch (interactionSubtype) {
						case "InboundNew":

							if (!group) {
								// try the To address, then fall through to the default group
								toAddress = getuData("_umsToAddr", interactionID);
								if (toAddress) {
									group = tryGroup(null, toAddress, null, "facebooksession");
								}
							}

							break;
						case "OutboundReply":
						case "OutboundAcknowledgement":
						case "OutboundAutoResponse":

							// is this a reply to an inbound interaction that was previously processed by GRA?
							group = getuData("GRA_FirstEntryGroup", interactionID);
							if (group) {
								group = tryGroup(group);
							}

							if (group) {
								break;
							}
							/* falls through */
						case "OutboundNew":

							// this an outbound interaction that was not yet processed by GRA
							fromAddress = getuData("_umsFromAddr", interactionID);
							if (fromAddress) {
								group = tryGroup(null, fromAddress, null, "facebooksession");
							}

							break;
					}

					break;
			}
		}

		// try a group based on interaction process and mediaType
		if (!group) {
			group = tryGroup();
		}
	}
	else {
		if ((group !== _data.OPM_Transaction) || !_data.system.context.OPM) { // jshint ignore: line
			group = tryGroup(group);
		}
	}

	if (!group) {
		throw new Error("invalid parameter-group \'" + requestedGroup + "\'");
	}

	if (getGroupContext._memoized[group]) {
		// we already memoized this group context
		__Log("GRA> picking up context for \'" + group + "\'");
		context = getGroupContext._memoized[group];

		// find the key that starts with a "GRA."
		Object.keys(context.OPM).some(function (key) {
			if (key.slice(0, 4) === "GRA.") {
				workflowKey = key;
			}
			return workflowKey;
		});
		if (!workflowKey) {
			throw new Error("didn't find the extra-arguments-key for parameter-group \'" + group + "\'");
		}	

		if (workflowKey === "GRA.basicReference.workflow") {
			// dereference 'GRA.basicReference.workflow'
			return getGroupContext(context.OPM.next);
		}

		return context;
	}
	else {
		// create a new context and memoize it
		__Log("GRA> preparing context for \'" + group + "\'");
		context = {};
		getGroupContext._memoized[group] = context;

		// the name of the parameter-group 
		context.group = group;

		// the operational parameters in this parameter-group
		if ((group === _data.OPM_Transaction) && _data.system.context.OPM) { // jshint ignore: line
			__Log("GRA> picking up OPM for \'" + group + "\' from \'system.OPM\'");
			OPM = _data.system.context.OPM;
		}
		else {
			__Log("GRA> loading OPM for \'" + group + "\'");
			try {
				if (_genesys.session.listLookupValue(group, "OPM")) {
					regularOPM = _genesys.session.getListItemValue(group, "OPM");
				}
			}
			catch (x1) {}
		}

		// the hidden operational parameters in this parameter-group
		hiddenGroup = "_restricted_" + group;
		__Log("GRA> loading OPM for \'" + hiddenGroup + "\'");
		try {
			if (_genesys.session.listLookupValue(hiddenGroup, "OPM")) {
				hiddenOPM = _genesys.session.getListItemValue(hiddenGroup, "OPM");
			}
		}
		catch (x2) {}

		// mix regularOPM and hiddenOPM into OPM
		OPM = {};
		if (regularOPM) {
			Object.keys(regularOPM).forEach(function (key) {
				OPM[key] = regularOPM[key];
			});
		}
		if (hiddenOPM) {
			Object.keys(hiddenOPM).forEach(function (key) {
				OPM[key] = hiddenOPM[key];
			});
		}

		if(!OPM) {
			throw new Error("didn't find the OPM values for parameter-group \'" + group + "\'");
		}
		else {
			// drop the key prefixes
			prefix = getInfrastructure().parameterKeyNamePrefix || "";
			context.OPM = {};
			Object.keys(OPM).forEach(function (key) {
				var newKey = key.slice(prefix.length);

				context.OPM[newKey] = OPM[key];
			});
		}
		
		// find the key that starts with a "GRA."
		Object.keys(context.OPM).some(function (key) {
			if (key.slice(0, 4) === "GRA.") {
				workflowKey = key;
			}
			return workflowKey;
		});
		if (!workflowKey) {
			throw new Error("didn't find the extra-arguments-key for parameter-group \'" + group + "\'");
		}	

		if (workflowKey === "GRA.basicReference.workflow") {
			// dereference 'GRA.basicReference.workflow'
			nextKey = "next";
		}
		else if (workflowKey === "GRA.mediaTypeBasedReference.workflow") {
			// dereference 'GRA.mediaTypeBasedReference.workflow'
			mediaType = getMediaType();
			nextKey = "nextFor" + (mediaKeyMap[mediaType] || (mediaType.slice(0, 1).toUpperCase() + mediaType.slice(1))) + "Media" ;
			if (!context.OPM[nextKey]) {
				nextKey = "exception";
			}
		}

		if (nextKey && context.OPM[nextKey]) {
			// dereference
			if (context.OPM[nextKey] !== group) {
				return getGroupContext(context.OPM[nextKey]);
			}
			else {
				throw new Error("cannot refer to self");
			}
		}
		else {
			// the name of the group-workflow
			context.workflow = workflowKey;

			// the extra arguments for this parameter-group
			try {
				__Log("GRA> parsing \'context.extra\'");
				context.extra = JSON.parse(
				    context.OPM[context.workflow]
				);
			}
			catch (e) {
				__Log("GRA> parsing \'context.extra\' failed - attempt workaround");
				// in some environments, we seem to need a second parse
				// not sure why
				context.extra = JSON.parse(
				    JSON.parse("\"" + context.OPM[context.workflow] + "\"")
				);
			}
		}

		return context;
	}
}
getGroupContext._memoized = {};

//##############################################################################
//#
//# getServers() -> servers
//#
//# gets the GRA servers and memoizes them.  
//# The servers is an object with structure:
//# {
//#     ChatServer: <ChatServer>,
//#     ClassificationServer: <ClassificationServer>,
//#     ContactServer: <ContactServer>,
//#     EmailServer: <EmailServer>,
//#     SIPSwitch: <SIPSwitch>,
//#     StatServer: <StatServer>
//# }
//#
function getServers() {
	"use strict";

	var section, servers;

	if (getServers._memoized) {
		return getServers._memoized;
	}

	section = "applications";
	__Log("GRA> looking up servers");
	if (_genesys.session.listLookupValue("Infrastructure", section)) {
		__Log("GRA> loading servers");
		servers = _genesys.session.getListItemValue("Infrastructure", section);
		getServers._memoized = servers;
		return servers;
	}
}
getServers._memoized = null;

//##############################################################################
//#
//# getInfrastructure(?section) -> infrastructure
//#
//# gets the GRA "general" infrastructure and memoizes it.  
//# The infrastructure is an object with structure:
//# {
//#     language: <language>
//# }
//#
function getInfrastructure() {
	"use strict";

	var section = arguments[0] || "general", infrastructure;

	if (getInfrastructure._memoized[section]) {
		return getInfrastructure._memoized[section];
	}

	__Log("GRA> looking up infrastructure for section '" + section + "'");
	if (_genesys.session.listLookupValue("Infrastructure", section)) {
		__Log("GRA> loading infrastructure for section '" + section + "'");
		infrastructure = _genesys.session.getListItemValue("Infrastructure", section);
		getInfrastructure._memoized[section] = infrastructure;
		return infrastructure;
	}
}
getInfrastructure._memoized = {};

//##############################################################################
//#
//# getLocalization(locale) -> localization
//#
//# gets the GRA "general" infrastructure and memoizes it.  
//# The infrastructure is an object with structure:
//# {
//#     language: <language>
//# }
//#
function getLocalization(locale) {
	"use strict";

	var section, localization;

	if (getLocalization._memoized[locale]) {
		return getLocalization._memoized[locale];
	}

	section = "localization:" + locale;
	__Log("GRA> looking up localization strings");
	if (_genesys.session.listLookupValue("Infrastructure", section)) {
		__Log("GRA> loading localization strings");
		localization = _genesys.session.getListItemValue("Infrastructure", section);
		getLocalization._memoized[locale] = localization;
		return localization;
	}
	else if (locale !== "ENU") {
		return getLocalization("ENU");
	}
}
getLocalization._memoized = {};

//##############################################################################
//#
//# isOnline(?interactionID) -> boolean
//#
function isOnline() { //jshint ignore: line
	"use strict";

	var category,
	    interactionID = arguments[0] || _data.system.context.InteractionID;

	category = _genesys.ixn.interactions[interactionID].category;
	return _genesys.ixn.interactions[interactionID][category]["is_online"]; //jshint ignore: line
}

//##############################################################################
//#
//# nextOpeningTimeText(time, appContext) -> text
//#
//# gets the string for the 'gra_NextOpeningTime' field code
//#
function nextOpeningTimeText(time, appContext) { //jshint ignore: line
	"use strict";
	var text;

	loadMoment(appContext.OPM.locale || "ENU");
	text = 
	   moment(time).format("LLLL") +
	   (appContext.OPM.timezoneIndicator ? " (" + appContext.OPM.timezoneIndicator + ")" : "");

	return text;
}

//##############################################################################
//#
//# regularOpeningHoursText(schedule, appContext) -> text
//#
//# gets the string for the 'gra_RegularOpeningHours' field code
//#
function regularOpeningHoursText(schedule, appContext) { //jshint ignore: line
	"use strict";

	var weekDayTexts, closedText, iterator, pattern,
	    text, i, j, n;
	
	// get the regular opening hours
	loadMoment(appContext.OPM.locale || "ENU");
	
	// a function to correct the time, avoiding invalid time 24:00
	function correctTime(hours, minutes) {
		if (hours <= 23) {
			return moment({
				hours: hours,
				minutes: minutes
			});
		}
		else {
			// change to 23:59
			return moment({
				hours: 23,
				minutes: 59
			});
		}
	}

	// a function to use as a callback
	function callback(range, index) {
		weekDayTexts[pattern.day] += 
			((index !== 0) ? ", " : "") +
			correctTime(range.begin.hours, range.begin.minutes).format("LT") +
			" - " +
			correctTime(range.end.hours, range.end.minutes).format("LT") +
			(appContext.OPM.timezoneIndicator ? " (" + appContext.OPM.timezoneIndicator + ")" : "");
	}

	weekDayTexts = moment.weekdaysShort();
	closedText = getLocalization(appContext.OPM.locale);
	closedText = (closedText && decodeURIComponent(closedText.Closed));
	iterator = new Schedule.Iterator(Schedule.convert(schedule));
	pattern = iterator.getNext();
	while (pattern) {
		weekDayTexts[pattern.day] += ": ";
		if (!pattern.ranges || (pattern.ranges.length === 0)) {
			weekDayTexts[pattern.day] += 
				closedText || "Closed";
		}
		else {
			pattern.ranges.forEach(callback);
		}

		pattern = iterator.getNext();
	}
	
	text = "";
	j = moment.localeData()._week && moment.localeData()._week.dow || 0;
	for (i = 0, n = weekDayTexts.length; i < n; i += 1) {
		text += ((i > 0) ? "\n" : "") + "   " + weekDayTexts[j];

		j += 1;
		if (j === n) {
			j = 0;
		}
	}

	return text;
}

//##############################################################################
//#
//# timeInQueueText(timeQueueEntered, timeQueueLeft) -> text
//#
//# gets the string for the 'GRA_TimeInQueue' user-data
//#
function timeInQueueText(timeQueueEntered, timeQueueLeft) { //jshint ignore: line
	"use strict";

	loadMoment(getInfrastructure().language);
	return moment.duration(moment(timeQueueLeft).diff(moment(timeQueueEntered))).stringify();
}
