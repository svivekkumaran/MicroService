/*------------------------------------------------------------------------------------------------------------------*/
/* GAX functions provided by Ates Goral to access Schedule parameters                                               */
/* http://ca-to-elora.us.int.genesyslab.com/openhours/                                                              */
/* YPD - 2012-08-14                                                                                                 */
/* Ioannis Faidros - 2012-08-21 - Replaced the content of this js file with the latest presented in the above URL   */
/* Ioannis Faidros - 2012-08-22 - Commented all the log entries of this js file                                     */
/* YPD - 2013-09-09 - Added new processDatePattern(s) functions for OpenHours and SpecialDay                        */
/* YPD - 2013-09-10 - Commented all the log entries of this js file                                                 */
/* YPD - 2013-09-11 - Deprecated functions checkTimeRanges, processPattern and processPatterns                      */
/* YPD - 2013-09-30 - Added function formatSeconds                                                                  */
/* YPD - 2013-10-21 - File replaced by schedule-utils.js except for function formatSeconds()						*/
/*------------------------------------------------------------------------------------------------------------------*/

function log(s) {
    if (window.console && window.console.log) {
        window.console.log(s);
    }

    ge("log").innerHTML += s + "\n";
}

function ge(id) { return document.getElementById(id); }

function formatSeconds(seconds)
{
    var date = new Date(1970,0,1);
    date.setSeconds(seconds);
    return date.toTimeString().replace(/.*(\d{2}:\d{2}:\d{2}).*/, "$1");
}

function checkDateMask(mask, dateStr) {
    //__Log("Checking date mask " + mask + " against " + dateStr);

    var maskTokens = mask.split("-"),
        dateTokens = dateStr.split("-");

    while (maskTokens.length) {
        var maskToken = maskTokens.shift(),
            dateToken = dateTokens.shift();

        if (maskToken !== "*" && maskToken !== dateToken) {
            //__Log("Token " + maskToken + " does not match " + dateToken);
            return false;
        }
    }
    
   //__Log("Date mask matches");
    return true;
}

function checkTimeRanges(ranges, timeStr) {
//Deprecated. Replaced by checkTimeRanges2
    if (ranges==''){
		//__Log("No time range defined");
	}
	else {
		//__Log("Checking time ranges " + ranges + " against " + timeStr);

		ranges = ranges.split(",");

		while (ranges.length) {
			var range = ranges.shift(),
				rangeTokens = range.split("-"),
				rangeStart = rangeTokens[0],
				rangeEnd = rangeTokens[1];

			if (timeStr >= rangeStart && timeStr <= rangeEnd) {
				//__Log("Range " + range + " matches");
				return true;
			}
		}
	}
    //__Log("No matching range found");
    return false;
}

function checkTimeRanges2(ranges, timeStr) {
    if (ranges==''){
		//__Log("No time range defined");
	}
	else {
		//__Log("Checking time ranges " + ranges + " against " + timeStr);

		ranges = ranges.split(",");

		while (ranges.length) {
			var range = ranges.shift(),
				rangeTokens = range.split("-"),
				rangeStart = rangeTokens[0],
				rangeEnd = rangeTokens[1];

			if (timeStr >= rangeStart && timeStr <= rangeEnd) {
				//__Log("Range " + range + " matches");
				return {
					rangematch: true,
					range: range
				}
			}
		}
	}
    //__Log("No matching range found");
	return {
		rangematch: false,
		range: ''
	}
}

function adjustTimeZone(date, timeZone) {
    var tzTokens = timeZone.split(":");
    var offsMins = parseInt(tzTokens[0], 10) * 60
            + parseInt(tzTokens[1], 10)
            + date.getTimezoneOffset();

    return new Date(date.getTime() + offsMins * 60 * 1000);
}

function parseDate(dateStr) {
    var dateTokens = dateStr.split(" "),
        datePart = dateTokens[0],
        timePart = dateTokens[1];

    return new Date(Date.parse([
        datePart.split("-").join("/"),
        timePart/*,
        timeZone*/
    ].join(" ")));
}

function formatDate(date) {
    function pad(n) {
        return n > 9
            ? n
            : "0" + n;
    }

    return [
        [
            date.getFullYear(),
            pad(date.getMonth() + 1),
            pad(date.getDate())
        ].join("-"),
        [
            pad(date.getHours()),
            pad(date.getMinutes())
        ].join(":")
    ].join(" ");
}

function processPattern(pattern, date) {
//Deprecated. Replaced by processDatePattern
    var dateStr = formatDate(date);
    //__Log("Processing pattern " + pattern + " against " + dateStr);

    var tokens = pattern.split("/"),
        type = tokens[0],
        timeZone = tokens[1],
        dateMask = tokens[2],
        timeRanges = tokens[3];

    if (timeZone) {
        date = adjustTimeZone(date, timeZone);
        dateStr = formatDate(date);
        //__Log("Adjusted date to " + dateStr);
    }

    var dateTokens = dateStr.split(" "),
        datePart = dateTokens[0],
        timePart = dateTokens[1];

    switch (type) {
    case "D":
        if (!checkDateMask(dateMask, datePart)) {
            //__Log("CheckDateMask result : " + checkDateMask(dateMask, datePart));
			return false;
        }
        break;
    case "W":
        if (parseInt(dateMask, 10) !== date.getDay()) {
            //__Log(parseInt(dateMask, 10)+' != '+date.getDay());
			return false;
        }
        break;
    default:
        //__Log("Unhandled pattern type " + type);
        return false;
    }

    return {
		match: checkTimeRanges(timeRanges, timePart)
    };
}

function processPatterns(patterns, date) {
//Deprecated. Replaced by processDatePatterns
    while (patterns.length) {
        var pattern = patterns.shift(),
            result = processPattern(pattern, date);
			//__Log("processPattern result = " + JSON.stringify(result));

        if (result) {
            return result.match;
        }
    }

    return false;
}

function processDatePattern(pattern, date) {
    var dateStr = formatDate(date);
    //__Log("Processing pattern " + pattern + " against " + dateStr);

    var tokens = pattern.split("/"),
        type = tokens[0],
        timeZone = tokens[1],
        dateMask = tokens[2],
        timeRanges = tokens[3];

    if (timeZone) {
        date = adjustTimeZone(date, timeZone);
         dateStr = formatDate(date);
        //__Log("Adjusted date to " + dateStr);
    }

    var dateTokens = dateStr.split(" "),
        datePart = dateTokens[0],
        timePart = dateTokens[1];

    switch (type) {
    case "D":
        if (!checkDateMask(dateMask, datePart)) {
            //__Log("CheckDateMask result : " + checkDateMask(dateMask, datePart));
			return {
				datematch: false,
				timematch: false
			};
        }
        break;
    case "W":
        if (parseInt(dateMask, 10) !== date.getDay()) {
			return {
				datematch: false,
				timematch: false
			};
        }
		//__Log("Date mask matches");
		break;
    default:
        //__Log("Unhandled pattern type " + type);
		return {
			datematch: false,
			timematch: false
		};
    }

	// match = true because date match
	// checkTimeRanges evaluates the timePart against timeRanges
	// For OpenHours : If timeRanges is null but date match, Routing application will consider date as closed
	// For SpecialDays : If timeRanges is null but date match, Routing application will consider date as closed

	var DatePattern = checkTimeRanges2(timeRanges, timePart);
	return {
		datematch: true,
		timematch: DatePattern.rangematch,
		patterntype: type,
		range: DatePattern.range
	};
}

function processDatePatterns(patterns, date) {
    while (patterns.length) {
        var pattern = patterns.shift(),
            result = processDatePattern(pattern, date);
			//__Log("processDatePattern result = " + JSON.stringify(result));

		if (result) {
			return result ;
        } 
    }

	return {
		datematch: false,
		timematch: false
	};
}