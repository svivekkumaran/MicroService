var Logging_version = "1.1.0";

var Customer = 'Enterprise_Digital';

/**
       Logging utility functions.

       Allows convenient grepping in log files to pull all logging statements for a given media type.
       Grep by 'CHAT Log' to get all chat logging statements.
       Grep by 'VOICE Log' to get all voice logging statements.
       Once all media type statements are segregated, grep again with the InteractionID to further winnow down
       all statements for a given interaction.
**/

//     e.g. 10-6-2015 <Customer> CHAT Log (00005aB15UDE01EE) 16:54:43.712:start...
function logStart(){
       return logStart_Prefix()+logPrefix();
       
}

function logStartLong(){
    return logStart_PrefixLong();
    
}
function logStart_PrefixLong(){
    return '#### Enterprise_Digital: Module STARTUP ********************** '+ 
    '</br> Code compilation: 06/23/2020 12:00pm'  + 
    '</br> Enterprise_Chat_Template rule template version supported: 4' + 
    '</br> Code Base: '+_data.system.context.BaseURL +
    '</br> Code Diagram: '+_data.system.context.diagram +
    '</br> ********************************************************</br>';
    
}

function logStart_Prefix(){
    return '#### Enterprise_Digital: Sub_Module STARTUP ****************** '+ 
    '</br> Code Diagram: '+_data.system.context.diagram + '</br>';
    
}

//     e.g. 10-6-2015 CHAT Log (00005aB15UDE01EE) 16:54:43.712:...end
function logEnd(){
       return logPrefix() + '...end';
}

// e.g. 10-6-2015 <Customer> CHAT Log (00005aB15UDE01EE) 16:54:43.712:CH_Inbound_WF:target=VAG_Chat_LLC@.GA
function logValue(varName,varValue){
       return logPrefix() +'</br>'+ varName+'</br>'+varValue;
}

// e.g. 10-7-2015 <Customer> CHAT Log (00005aB15UDE01EE) 7:57:21.950:CH_Inbound_WF:routeType not found.  Setting routeType to DEFAULT
function logMsg(msg){
       return logPrefix() +'</br>'+ msg;
}

// e.g. 10-7-2015 <Customer> CHAT Log (00005aB15UDE01EE) 7:57:21.950:CH_Inbound_WF: An error occurred fetching standard response.  Error=Application with specified name 'undefined' not found.
function logError(msg){
       return logPrefix() +  msg + '. Error=' + _data.system.context.LastErrorEvent.message;

}

function logPrefix(){
             var today = new Date();
             var date = (today.getMonth()+1)+'-'+today.getDate()+'-'+today.getFullYear();
             var timeOfDay = today.getHours()+':'+today.getMinutes()+':'+today.getSeconds()+'.'+today.getMilliseconds();
             return '#### '+Customer+': '+_data.system.context.currentBlock;
}

function logJSON(msg, json){
	if(json!=null){
		return logPrefix() + msg + '=' +JSON.stringify(json);
	}else{
		return logPrefix() + msg + '=null';
	}
}



